import React from "react";

function Portfolio() {
  return (
    <div>
      <header>
        <h1>Your Name</h1>
        <p>Front-End Developer</p>
      </header>
      <section id="bio">
        <h2>About Me</h2>
        <p>Welcome to my portfolio. I create web experiences that matter.</p>
      </section>
      <section id="projects">
        <h2>Projects</h2>
        <div className="project">
          <img src="projectA.jpg" alt="Project A" />
          <h3>Project A</h3>
          <p>Description of Project A.</p>
        </div>
        <div className="project">
          <img src="projectB.jpg" alt="Project B" />
          <h3>Project B</h3>
          <p>Description of Project B.</p>
        </div>
      </section>
      <section id="contact">
        <h2>Contact</h2>
        <p>Contact me at your.email@example.com</p>
      </section>
      <footer>
        <p>&copy; 2023 Your Name</p>
      </footer>
    </div>
  );
}

export default Portfolio;
